#!/bin/bash

sudo true || exit 1

cd "$(dirname $(readlink -f $0))"

echo 'Connecting...'
sudo openvpn --config ./myvpn.ovpn 2>&1
echo 'Disconnected...'
