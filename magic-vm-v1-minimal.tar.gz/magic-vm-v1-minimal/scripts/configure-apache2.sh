#!/bin/bash

sudo true || exit 1

sudo sed -i 's@Listen 80@Listen 50080@g' /etc/apache2/ports.conf

sudo service apache2 restart
