#!/bin/bash

sudo true || exit 1

cat <<EOF | sudo tee /etc/resolv.conf &> /dev/null
nameserver 8.8.8.8
nameserver 8.8.4.4
EOF

if [ -z "$@" ]; then
  sleep 60
fi
