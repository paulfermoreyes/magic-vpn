#!/bin/bash

sudo true || exit 1

cat <<EOF | sudo tee /etc/squid/squid.conf &> /dev/null
dns_nameservers 8.8.8.8 8.8.4.4
acl all src all
http_access allow all
http_access deny all
http_port 53128
EOF

sudo service squid restart

