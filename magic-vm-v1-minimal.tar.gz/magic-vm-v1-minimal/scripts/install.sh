#!/bin/bash

sudo true || exit 1

cd "$(dirname $(readlink -f $0))"

source /etc/os-release
if [ "${VERSION_CODENAME}" != 'focal' ]; then
  echo 'Can only be installed in Ubuntu 20.04 (FOCAL FOSSA)'
  exit 1
fi

if [ -r '/var/log/pm2-ovpn-installed' ]; then
  exit 0
fi

sudo apt-get clean
sudo apt-get autoclean
sudo rm -rf /var/lib/apt/lists/*

sudo mv /etc/apt/sources.list /etc/apt/sources.list.bak
sudo mv /etc/apt/sources.list.d /etc/apt/sources.list.d.bak
sudo cp ./apt/sources.list /etc/apt/sources.list
sudo mkdir /etc/apt/sources.list.d

RDEPS='squid apache2 openvpn nodejs npm'
IDEPS="openssh-client openssh-server ${RDEPS}"

./configure-dns.sh 1

sudo apt-get update || exit 1
sudo apt-get remove --purge -y ufw ${RDEPS} || exit 1
sudo apt-get install -y ${IDEPS} || exit 1
sudo npm install -g pm2
sudo pm2 startup
sudo systemctl enable --now pm2-root

echo 'Configuring apache2...'
./configure-apache2.sh
echo 'Configuring squid...'
./configure-squid.sh

echo 'Configuring PACs...'
echo 'Your IPs:'
hostname -I | sed 's@ @\n@g' | grep -v '^$'
read -p 'Type-in your preferred IP for PAC: ' DA_IP

sudo rm -rf /var/www/html/pac
sudo cp -r ./pac /var/www/html/
sudo sed -i "s@{{DA_IP}}@${DA_IP}@g" /var/www/html/pac/*

echo 'DONE'
sudo touch /var/log/pm2-ovpn-installed
