#!/bin/bash

sudo true || exit 1

./scripts/install.sh || exit 1

sudo pm2 start ./pm2.yaml
sudo pm2 save
