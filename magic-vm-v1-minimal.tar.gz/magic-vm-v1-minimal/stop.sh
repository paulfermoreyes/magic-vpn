#!/bin/bash

sudo true || exit 1

sudo pm2 delete ./pm2.yaml
sudo pm2 save --force
